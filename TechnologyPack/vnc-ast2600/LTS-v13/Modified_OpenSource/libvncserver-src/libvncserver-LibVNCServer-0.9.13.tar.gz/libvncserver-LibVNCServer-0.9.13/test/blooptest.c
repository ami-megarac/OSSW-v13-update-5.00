#define BACKGROUND_LOOP_TEST
#include "../examples/example.c"
